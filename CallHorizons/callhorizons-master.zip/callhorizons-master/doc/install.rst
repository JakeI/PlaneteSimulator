Installation
------------

PIP
~~~

Using PIP, simply call::

  pip install callhorizons


GitHub
~~~~~~

Using git, simply clone the code from GitHub::

  git clone https://github.com/mommermi/callhorizons

or, download and unpack the zip file with all the files from `GitHub`_
and then run from the callhorizons directory::

  python setup.py install



.. _GitHub: https://github.com/mommermi/callhorizons
